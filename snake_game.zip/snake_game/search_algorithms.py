import random
from collections import deque
import heapq

# Directions (Up, Down, Left, Right)
DIRECTIONS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

# Random movement algorithm (provided)
def random_move(start, goal, obstacles, rows, cols):
    path = []
    current = start

    for _ in range(1000):  # Limit to 1000 moves
        direction = random.choice(DIRECTIONS)
        new_pos = (current[0] + direction[0], current[1] + direction[1])

        if (
            0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
            new_pos not in obstacles
        ):
            path.append(direction)
            current = new_pos

        if current == goal:
            return path

    return []  # If it takes too long, return empty path


# Breadth First Search (BFS) Algorithm
def bfs(start, goal, obstacles, rows, cols):
    queue = deque([(start, [])])  # (current_position, path)
    visited = set()

    while queue:
        current, path = queue.popleft()

        if current == goal:
            return path

        if current in visited:
            continue

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                queue.append((new_pos, path + [direction]))

    return []  # No path found


# Depth First Search (DFS) Algorithm
def dfs(start, goal, obstacles, rows, cols):
    stack = [(start, [])]  # (current_position, path)
    visited = set()

    while stack:
        current, path = stack.pop()

        if current == goal:
            return path

        if current in visited:
            continue

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                stack.append((new_pos, path + [direction]))

    return []  # No path found


# Iterative Deepening Search (IDS) Algorithm
def ids(start, goal, obstacles, rows, cols):
    def depth_limited_search(current, goal, obstacles, rows, cols, depth, path, visited):
        if current == goal:
            return path

        if depth <= 0:
            return None

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                result = depth_limited_search(new_pos, goal, obstacles, rows, cols, depth - 1, path + [direction], visited.copy())
                if result:
                    return result

        return None

    depth = 0
    while True:
        visited = set()
        result = depth_limited_search(start, goal, obstacles, rows, cols, depth, [], visited)
        if result:
            return result
        depth += 1


# Uniform Cost Search (UCS) Algorithm
def ucs(start, goal, obstacles, rows, cols):
    heap = [(0, start, [])]  # (cost, current_position, path)
    visited = set()

    while heap:
        cost, current, path = heapq.heappop(heap)

        if current == goal:
            return path

        if current in visited:
            continue

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                heapq.heappush(heap, (cost + 1, new_pos, path + [direction]))

    return []  # No path found


# Heuristic function for Greedy BFS and A*
def manhattan_distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


# Greedy Best First Search Algorithm
def greedy_bfs(start, goal, obstacles, rows, cols):
    heap = [(manhattan_distance(start, goal), start, [])]  # (heuristic, current_position, path)
    visited = set()

    while heap:
        _, current, path = heapq.heappop(heap)

        if current == goal:
            return path

        if current in visited:
            continue

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                heapq.heappush(heap, (manhattan_distance(new_pos, goal), new_pos, path + [direction]))

    return []  # No path found


# A* Search Algorithm
def astar(start, goal, obstacles, rows, cols):
    heap = [(0 + manhattan_distance(start, goal), 0, start, [])]  # (f_cost, g_cost, current_position, path)
    visited = set()

    while heap:
        _, g_cost, current, path = heapq.heappop(heap)

        if current == goal:
            return path

        if current in visited:
            continue

        visited.add(current)

        for direction in DIRECTIONS:
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            if (
                0 <= new_pos[0] < rows and 0 <= new_pos[1] < cols and
                new_pos not in obstacles and new_pos not in visited
            ):
                heapq.heappush(heap, (g_cost + 1 + manhattan_distance(new_pos, goal), g_cost + 1, new_pos, path + [direction]))

    return []  # No path found